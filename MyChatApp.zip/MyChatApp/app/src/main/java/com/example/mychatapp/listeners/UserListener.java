package com.example.mychatapp.listeners;

import com.example.mychatapp.models.User;

public interface UserListener {
    void onUserClicked(User user);
}
